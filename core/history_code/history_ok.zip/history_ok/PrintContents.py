from HistoryChatManager import HistoryChatManager

# 初始化历史记录管理器
history_manager = HistoryChatManager()

def print_response(response, is_stream):
    if is_stream:
        response_text = ""
        for chunk in response:
            if chunk.choices[0].delta.content:
                print(chunk.choices[0].delta.content, end='', flush=True)
                response_text += chunk.choices[0].delta.content
        print()
        # 将流式响应的完整消息添加到历史记录中
        history_manager.add_message("assistant", response_text)
    elif not is_stream:
        print(response.choices[0].message.content)
        # 将非流式响应的完整消息添加到历史记录中
        history_manager.add_message("assistant", response.choices[0].message.content)
    else:
        raise TypeError("is_stream must be Bool type")