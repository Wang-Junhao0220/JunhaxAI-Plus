def print_response(response, is_stream):
    if is_stream:
        for chunk in response:
            if chunk.choices[0].delta.content:
                print(chunk.choices[0].delta.content, end='', flush=True)
    elif not is_stream:
        print(response.choices[0].message.content)
    else:
        raise TypeError("is_stream must be Bool type")