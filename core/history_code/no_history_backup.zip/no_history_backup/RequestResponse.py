# Please install OpenAI SDK first: `pip3 install openai`

from openai import OpenAI

# API_KEY = "sk-412f81f433a74a8dbce46756d9acd508"
# BASE_URL = "https://api.deepseek.com"
SYSTEM_MESSAGE = "You are a helpful assistant"
TEMPERATURE = 0.8
MAX_TOKENS = 4096
MODEL_NAME = "xdeepseekv3"
API_KEY = "sk-Qo8c77pIOMToiZ8y8fD92b7d096c471896B064C14c8809A9"
BASE_URL = "https://maas-api.cn-huabei-1.xf-yun.com/v1"


def create_client(apiKey=API_KEY, baseUrl=BASE_URL):
    client = OpenAI(api_key=apiKey, base_url=baseUrl)
    return client


def change_system_message(newSysMessage):
    global SYSTEM_MESSAGE
    SYSTEM_MESSAGE = newSysMessage


def change_temperature(newTemperature):
    # 增加验证器，保证 temperature在0-1之间
    if newTemperature < 0 or newTemperature > 1:
        raise ValueError("temperature must be between 0 and 1")
    global TEMPERATURE
    TEMPERATURE = newTemperature


def change_max_tokens(newMaxTokens):
    global MAX_TOKENS
    MAX_TOKENS = newMaxTokens


def change_model_name(newModelName):
    global MODEL_NAME
    MODEL_NAME = newModelName


def request_response(userMessage, modelName=MODEL_NAME, previousMessages=None, streamResponse=True,
                     systemMessgae=SYSTEM_MESSAGE, temperature=TEMPERATURE, maxTokens=MAX_TOKENS):
    messages = [{"role": "system", "content": systemMessgae}, {"role": "user", "content": userMessage}]

    response = create_client().chat.completions.create(
        model=modelName,
        messages=messages,
        stream=streamResponse,
        temperature=temperature,
        max_tokens=maxTokens,
    )
    return response

# client = OpenAI(api_key=API_KEY, base_url=BASE_URL)
#
# response = client.chat.completions.create(
#     model="deepseek-chat",
#     messages=[
#         {"role": "system", "content": "You are a helpful assistant"},
#         {"role": "user", "content": "Hello"},
#     ],
#     stream=False
# )
#
# print(response.choices[0].message.content)
