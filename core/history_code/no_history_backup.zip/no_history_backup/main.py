# 导入core
import RequestResponse
import PrintContents

# Bug: 流式响应无法打印 2025-02-22-22：55：30
# 测试多轮对话功能
def test_multi_turn_conversation():
    # 第一次对话
    first_message = "Hello!"
    first_response = RequestResponse.request_response(first_message, "xdeepseekv3", streamResponse=True)
    # print("First Response:", first_response.choices[0].message.content)
    PrintContents.print_response(first_response, True)
    
    # 第二次对话
    second_message = "What did I say before?"
    second_response = RequestResponse.request_response(second_message, "xdeepseekv3", streamResponse=False)
    PrintContents.print_response(second_response, False)

# 运行测试
test_multi_turn_conversation()